import json, os
from datetime import datetime

class NotesManager:
    def __init__(self):
        self.file="data/notes.json"
        os.makedirs("data",exist_ok=True)
        self.notes=[]
        self.load()

    def load(self):
        try:
            with open(self.file) as f:
                self.notes=json.load(f)
        except:
            self.notes=[]

    def save(self):
        with open(self.file,"w") as f:
            json.dump(self.notes,f,indent=2)

    def run(self):
        while True:
            print("1.View 2.Add 3.Back")
            c=input("Choice: ")
            if c=="1":
                for n in self.notes:
                    print(n)
            elif c=="2":
                t=input("Title: ")
                c=input("Content: ")
                self.notes.append({"title":t,"content":c,"time":str(datetime.now())})
                self.save()
            elif c=="3":
                break
            input("Enter...")
