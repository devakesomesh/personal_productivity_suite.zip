class Calculator:
    def run(self):
        while True:
            print("1.Add 2.Sub 3.Mul 4.Div 5.Back")
            ch=input("Choice: ")
            if ch=="5": break
            a=float(input("A: "))
            b=float(input("B: "))
            if ch=="1": print(a+b)
            elif ch=="2": print(a-b)
            elif ch=="3": print(a*b)
            elif ch=="4": print(a/b)
            input("Enter...")
